module.exports = {
  email: {
    service: 'gmail',
    auth: {
      user: 'your-email@gmail.com',
      pass: 'your-email-password'
    }
  },
  twilio: {
    accountSid: 'your-twilio-sid',
    authToken: 'your-twilio-token',
    from: 'whatsapp:+14155238886',
    to: 'whatsapp:+967782200177'
  },
  recipientEmail: 'ibmshibmsh@gmail.com'
};